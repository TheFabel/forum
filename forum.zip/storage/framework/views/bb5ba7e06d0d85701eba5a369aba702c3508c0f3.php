<?php $__env->startSection('content'); ?>
    <div class="theme_content">
        <div class="row mb-5">
            <div class="col-12">
                <a href="/">Назад</a>
                <h1><?php echo e($theme->name); ?></h1>
                <p><?php echo e($theme->text); ?></p>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <h3>Сообщения:</h3>
                <div class="comments-list">
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border-bottom">
                            <p class="text-right"><small>
                                <?php
                                    $time = $comment->date;
                                    $date = new DateTime();
                                    $date->setTimestamp($time);
                                    echo $date->format("Y-d-m H:i:s");
                                ?>
                            </small></p>
                            <div class="">

                                <p><?php echo e($comment->text); ?></p>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($comments->links()); ?>

            </div>
        </div>

        <form class="comment_add" action="/add" method="POST">
            <div class="form-group">
                <label for="comment">Оставить сообщение:</label>
                <textarea class="form-control" rows="5" id="comment" required></textarea>
            </div>
            <input type="hidden" id="theme_id" value="<?php echo e($theme->id); ?>">
            <button type="submit" class="btn btn-primary">Отправить</button>
        </form>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/form.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>