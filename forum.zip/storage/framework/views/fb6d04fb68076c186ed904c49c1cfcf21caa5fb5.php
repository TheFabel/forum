<?php $__env->startSection('content'); ?>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">Название темы</th>
            <th scope="col">Ответов (просмотров)</th>
            <th scope="col">Последнее сообщение</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($theme->name); ?></td>
                <td><?php echo e($theme->answers.' ('.$theme->views.')'); ?></td>
                <td><?php echo e($theme->last_answer); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($themes->links()); ?>


    <?php
    echo microtime(true) - $time;

    ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>