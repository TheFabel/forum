@extends('layouts.default')

@section('content')
    <table class="table">
        <thead>
        <tr>
            <th scope="col">Название темы</th>
            <th scope="col">Ответов (просмотров)</th>
            <th scope="col">Последнее сообщение</th>
        </tr>
        </thead>
        <tbody>
        @foreach($themes as $theme)
            <tr>
                <td><a href="/theme/{{$theme->id}}">{{$theme->name}}</a></td>
                <td>{{$theme->answers.' ('.$theme->views.')'}}</td>
                <td>{{$theme->last_answer}}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    {{$themes->links()}}

    <?php
    echo microtime(true) - $time;

    ?>
@endsection