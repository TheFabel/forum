<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Theme extends Model
{
    protected $table = 'themes';

    public $primaryKey = 'id';

    public function getCommentsList($id)
    {
        return Answer::where('theme_id', $id)->orderBy('date', 'asc')->paginate(10);
    }
}
