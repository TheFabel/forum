<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Theme;

class PagesController extends Controller
{
    public function index()
    {
        $themes = ThemesController::index();
        $time = microtime(true);
        $data = array(
            'title' => 'Главная страница',
            'themes' => $themes,
            'time' => $time
        );
        return view('pages.index')->with($data);
    }
    public function theme($id)
    {
        if (filter_var($id, FILTER_VALIDATE_INT) === false)
            echo "There's been an error";
        $theme = ThemesController::showTheme($id);
        $t = Theme::find($id);
        $comments = $t->getCommentsList($id);
        $data = array(
            'title' => $theme->name,
            'theme' => $theme,
            'comments' => $comments
        );
        return view('pages.theme')->with($data);
    }
}
